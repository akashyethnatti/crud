package com.example.junit.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.junit.model.Student;
import com.example.junit.repository.StudentRepo;

@RestController
public class StudentController {

	@Autowired
	
	StudentRepo studentrepo;
	
	@PostMapping("/addStudent")
	public String addstudent(@RequestBody Student stu) {
		studentrepo.save(stu);
		return "record inserted successfully";
	}
	
	@GetMapping("/display/{sid}")
	public Optional<Student> display(@PathVariable int sid) {
		return studentrepo.findById(sid);
		
	}
	
	@DeleteMapping("/delete/{sid}")
	public String delete(@PathVariable int sid) {
		studentrepo.deleteById(sid);
		return"record deleted successfully";
	}
	@PutMapping("/update/{sid}")
	public String update(@RequestBody Student stu,@PathVariable int sid) {
		studentrepo.deleteById(sid);
		studentrepo.save(stu);
		return "record updated successfully at"+sid;
	}
	
}
