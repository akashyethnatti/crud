package com.example.junit.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.junit.model.Student;

public interface StudentRepo extends MongoRepository<Student,Integer> {

}
