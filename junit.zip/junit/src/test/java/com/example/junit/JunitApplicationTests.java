package com.example.junit;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.junit.model.Student;
import com.example.junit.repository.StudentRepo;

@SpringBootTest
class JunitApplicationTests {
@Autowired
	StudentRepo studentrepo;
	@Test
	public void create() {
		Student pp=new Student();
		pp.setSid(4);
		pp.setSname("girish");
		pp.setSclg("jce");
		pp.setSaddress("mysuru");
		studentrepo.save(pp);
		
	}
	
	@Test
	public void read() {
		Iterable<Student>List=studentrepo.findAll();
	}
	
	@Test
	public void delete() {
		studentrepo.deleteById(0);
	}
	@Test
	public void update() {
		Student pp=studentrepo.findById(0).get();
				pp.setSid(0);
				pp.setSname("");
				studentrepo.save(pp);
	}

}
