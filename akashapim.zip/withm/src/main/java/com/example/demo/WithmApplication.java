package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WithmApplication {

	public static void main(String[] args) {
		SpringApplication.run(WithmApplication.class, args);
	}

}
